#testfoci.m -- for testing rad-51 counting

fflush(stdout);
W=3;HW=floor(W/2);
DATAFILE=input("Enter data file:","S");
if(isempty(DATAFILE)),
DATAFILE="/data3/data2/aya/20130528_ce158_rad54pph4/20130531_rad54_24hpL4_RAD51_R3D_D3D.dv.zs"
end

DAPI=input("Wavelength for DAPI (1,2,3..) ->");
if(isempty(DAPI)),DAPI=1;end

RAD=input("Wavelength for FOCI (1,2,3..) ->");
if(isempty(RAD)),RAD=2;end;
if(DAPI==RAD),disp("YOUR WAVELENGTHS ARE BAD AND YOU SHOULD FEEL BAD");end

NWAV=input("Total number of wavelengths ->");
if(isempty(NWAV)),NWAV=2;end;
if(NWAV<max(DAPI,RAD)), disp("YOU SHOULD HAVE MORE WAVELENGTHS!");end

disp("reading file...");fflush(1);
dat=mrcread(DATAFILE);
ds=size(dat);
zs=reshape(1:ds(3),[ds(3)/NWAV NWAV]);

DAPI=dat(:,:,zs(:,DAPI));
RAD=dat(:,:,zs(:,RAD));

clear dat;

RAD-=min(RAD(:));
RAD./=max(RAD(:)); #normalized

disp("calculating point maxima...");fflush(1);
maxrad=max(RAD,[],3);level=graythresh(maxrad);
mtt=maxrad(find(maxrad>level));level=mean(mtt)-std(mtt); #go down 1 std
mtt=maxrad(find(maxrad>level));level=mean(mtt)-std(mtt); #go down another std

localmax=minmaxfilt(RAD,W,'max','same'); #requires MinMaxFilt package .mex files 20130607pmc
radsignals=( (localmax==RAD) .* (RAD >= level) );

disp("finding nucleus centers...");fflush(1);
DAPI-=min(DAPI(:));
DAPI./=max(DAPI(:)); #normalized
maxdapi=max(DAPI,[],3);dlevel=graythresh(maxdapi);
localmax=minmaxfilt(DAPI,W,'max','same');
dapisignals=( (localmax==DAPI) .* (DAPI>= dlevel) );
f=find(dapisignals);[dx dy dz]=ind2sub(size(DAPI),f);
dpts=[dx dy dz].*repmat([.064 .064 .2],[length(dx) 1]);
printf("using %i peaks...",length(f));
rad=2;bb=dpts;o=2;
pmove=30;
for ll=1:pmove;
    aa=bb;
    for l=1:length(dpts);
        r=repmat(aa(l,:),[length(aa) 1]);
        r=sqrt(sum((aa-r).^2,2));
        r(find(r==0))=(max(r)+(2*rad));
        f=find(r<rad);
        if(f),
            r=mean(aa(f,:))-aa(l,:);
            xx=r./sqrt(sum(r.^2));
            bb(l,:)=aa(l,:)+(xx./o);
        end
        mpts{ll}=bb;
    end
    printf("%i ",pmove-ll);fflush(1);
end
#hold off;figure;hold on;for l=1:o;r=mpts{l}(:,1:2);plot(r(:,1),r(:,2),'.','color',[l/pmove 0 1]);end

#now center clusters are in bb
#replace all points <2rad with 0

for l=1:length(bb);
    r=bb(l,:);
    if(r),
        f=find(bb(:,1));
        r=repmat(r,[length(f) 1]);
        r-=bb(f,:);
        r=sqrt(sum(r.^2,2));
        ff=find(r<(2*rad));
        bb(f(ff(2:end)),:)=0;
        end
    end

nuccenters=bb(find(bb(:,1)),:);

#disp("pruning based on DAPI...");fflush(1);
disp("counting foci...");fflush(1);

f=find(radsignals);
[x,y,z]=ind2sub(size(RAD),f);
foci=[x y z].*repmat([.064 .064 .2],[length(x) 1]);

#for l=1:length(f);
#     [x,y,z]=ind2sub(size(DAPI),f(l));
#     r=DAPI(x-HW:x+HW,y-HW:y+HW,z-HW:z+HW);
#     ds(l)=sum(r(:)>dlevel);
#     end
# im(max(radsignals,[],3));

output=countfoci(nuccenters, foci,maxdapi,maxrad);
