function u=dprimepic(o);

%some picture with prime distances
size=2600;

u=zeros(size);
r=diff(primes(o));
r=ceil(r./2);

%x=floor(size/2);
%y=floor(size/2);

x=500;y=500;

df=[1 0 -1 0;0 1 0 -1];

rl=length(r);
for l=1:rl;
  dr=1+mod(l,4);
  ux=x; uy=y;
  dx=df(1,dr); dy=df(2,dr);

if(dx), x=x+(r(l)*dx); xr=(ux:sign(dx):x); else xr=x; end
if(dy), y=y+(r(l)*dy); yr=(uy:sign(dy):y); else yr=y; end

  if(min([xr yr])>0),
	u(xr,yr) = u(xr,yr) + 1;end
end


  
