function y=emin(x);
    y=abs((x^x)-e);
%y=abs(((x^x)^x)-((1+sqrt(5)/2)));
    end

