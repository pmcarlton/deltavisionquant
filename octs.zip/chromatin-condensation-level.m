Quantification of Chromatin Condensation Level by Image Processing
Jerome Irianto, David A. Lee, Martin M. Knight
Institute of Bioengineering, School of Engineering and Materials Science, Queen Mary, University of London

MATLAB code for main function (Main.m)
clear all;
clc
 
%% =================== List of image matrices ============================
%I  = original image
%I2 = original image smoothed by mean filter (6x)
%I3 = image of pixels that above the threshold (T)
%I4 = image of pixels that above the threshold with the holes filled
%I5 = image of the thresholded nucleus in black background plus intensity
%     redistributed
%I6 = downsampled I5 into 128x128 (by a factor of 4)
%I7 = SOBEL image (logical)
%A1 = SOBEL image (uint8) 
%I8 = image of pixels that above the threshold from 128x128 image (I6)
%I9 = image of pixels that above the threshold from 128x128 image with the
%     holes filled
%I10 = the inner part of the nucleus (Region of Interest or ROI)
%I11 = perimeter of the ROI
%I12 = image of the SOBEL edge within the ROI
%I13 = image of the SOBEL edge within the ROI (I12) plus the perimeter of
%      previous ROI (I11)
 
%% ================== INPUT ==============================================
%These are the required inputs for the algorithm.
%XLfilename:    The name given to the EXCEL file to be produced, this will
%               contain the area, edge count and edge density from each 
%               image.
%filenames:     This will search the folder for the images name specified.
%
%If you want to print out an image matrix, give the value 1. If not
%required, give the value 0.
%
%PixRedFaxtor:  Image reduction factor.
%SobelThresh:   The threshold value for the SOBEL edge detection.
%=========================================================================
 
XLfilename = 'Results AREA EDGECOUNT EDGEDENSITY.xls';
filenames = dir('*ch00.tif');
 
PrintI2 = 0;
PrintI3 = 0;
PrintI4 = 0;
PrintI5 = 0;
PrintI6 = 0;
PrintI7 = 0;
PrintA1 = 0;
PrintI8 = 0;
PrintI9 = 0;
PrintI10 = 0;
PrintI11 = 0;
PrintI12 = 0;
PrintI13 = 0;
 
PixRedFactor = 4;
SobelThresh = 0.09;
 
%% ===== Producing file names for image matrices to be printed out =======
 
PrintIndex = [PrintI2;PrintI3;PrintI4;PrintI5;PrintI6;PrintI7;PrintA1;...
    PrintI8;PrintI9;PrintI10;PrintI11;PrintI12;PrintI13];
s = numel(filenames);
[PrintNameList] = GeneratingPrintName(PrintIndex,s);
 
%% =================== CORE algorithm ====================================
 
Arealist = zeros(s,1);
edgecountlist = zeros(s,1);
edgedenlist = zeros(s,1);
 
for q=1:numel(filenames)
    %Load image
    I = imread(filenames(q).name);
    
    %Acquire threshold value for I
    [T] = ThreshMode(I);
    
    %Image average smoothening by (i)th times
    I2 = I;
    for i = 1:6
        h = fspecial('average');
        I2 = imfilter(I2,h);       
    end
    
    %Thereshold application to I2
    [I3] = ApplyThresh(I2,T);
    I3 = logical(I3);               
    
    %Hole-filling algorithm
    I4 = imfill(I3,'holes');        
 
    %Extract the nucleus from the original image to a black background
    [I5] = ExtractImage(I,I4);
    I5 = uint8(I5);
 
    %Intensity redistribution for I5
    A = max(max(I5));               
    B = double(I5);
    C = double(A);
    I5 = (B/C)*255;
    I5 = uint8(I5);
 
    %Image reduction by a factor of 4 (1/4 = 0.25)
    PixRed = 1/PixRedFactor;
    I6 = imresize(I5,PixRed);         
 
    %Intensity redistribution for I6
    A = max(max(I6));               
    B = double(I6);
    C = double(A);
    I6 = (B/C)*255;
    I6 = uint8(I6);
 
    %SOBEL edge detection application
    I7 = edge(I6,'sobel',SobelThresh);        
    A1 = uint8(I7);
    A1 = A1*255;
 
    %Acquire threshold value for I6
    clear T
    [T] = ThreshMode(I6);
 
    %Threshold application to I6
    [I8] = ApplyThresh(I6,T);
    I8 = logical(I8);
    
    %Hole-filling algorithm
    I9 = imfill(I8,'holes');
 
    %Perimeter subtraction by (n)th times
    I10 = I9;
    n = 2;                          
    for i = 1:n                    
        I11 = bwperim(I10);
        I10 = I10-I11;
        I10 = logical(I10);
    end
    
    %Extract the SOBEL edge inside the nucleus into a black background
    [I12] = ExtractImage(I7,I10);
    I12 = logical(I12); 
    I13 = I12+I11;                    
    I13 = uint8(I13);
    I13 = I13*255;
 
    %Nucleus area
    [row,column,int] = find(I10>0); 
    S = length(row);
    Area = S;
    Arealist(q,1) = Area;
 
    %Edge count
    edgecount = sum(sum(I12));
    edgecountlist(q,1) = edgecount;
 
    %Edge density (i.e. chromatin condensation parameter)
    edgeden = (edgecount/Area)*100;
    edgedenlist(q,1) = edgeden;
 
    I12 = uint8(I12);
    I12 = I12*255;
    [PrintList] = GeneratingPrint(PrintIndex,u,PrintNameList,I2,I3,I4,...
        I5,I6,I7,A1,I8,I9,I10,I11,I12,I13);
end
 
xlswrite(XLfilename,Arealist,1);
xlswrite(XLfilename,edgecountlist,2);
xlswrite(XLfilename,edgedenlist,3);
















MATLAB code for sub-function ThreshMode.m
function [Thresh] = ThreshMode(I)
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function receive the image to be thresholded.
%This function then produce a threshold value by the mode method.
%I: image to be thresholded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
I = double(I);
MaxInt = max(max(I));
MaxInt = single(MaxInt);
 
H = hist(I(:),0:MaxInt);
 
Iteration = 0;
Cond = 0;
 
while Cond == 0
    F = ones(1,3)/3;
    H = conv2(H,F,'same');
    
    Sy = size(H,2);
    Peak = 0;
    
    for i = 2:Sy-1
        if Peak < 3
            if H(i-1)<H(i) && H(i+1)<H(i)
                Peak = Peak+1;
            end
        end
    end
    
    if Peak > 2
        Cond = 0;
    else
        Cond = 1;
    end
    
    Iteration = Iteration + 1;                
            
    if Iteration > 10000
        Thresh = 0;
        return
    end
end
 
for j = 2:MaxInt
  if H(j-1)>H(j) && H(j+1)>H(j)
    Thresh = j-1;
  end
end








MATLAB code for sub-function ApplyThresh.m
function [IThresh] = ApplyThresh(I,T)
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function receive the image to be thresholded and the threshold value.
%This function then produce a thresholded image.
%I: image to be thresholded
%T: threshold value
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
clear row column int S sizerow sizecolumn R C
 
[row,column,int] = find(I>T);  
S = length(row);
[sizerow,sizecolumn] = size(I);
IThresh = zeros(sizerow,sizecolumn);
for i = 1:S
    R = row(i,1);
    C = column(i,1);
    IThresh(R,C) = 1;          
end



















MATLAB code for sub-function ExtractImage.m
function [IExtract] = ExtractImage(I,In)
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function receive the image to be extracted to a black background and
%the thresholded image (having the pixels locating where the target is).
%This function then produce a target image with black background.
%I:     target image
%In:    thresholded image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
clear row column int S sizerow sizecolumn R C
 
[row,column,int] = find(In>0); 
S = length(row);
[sizerow,sizecolumn] = size(In);
IExtract = zeros(sizerow,sizecolumn);
for i = 1:S
    R = row(i,1);
    C = column(i,1);
    IExtract(R,C) = I(R,C);       
end



















MATLAB code for sub-function GeneratingPrint.m
function [PrintList] = GeneratingPrint(PrintIndex,q,PrintNameList,I2,I3,I4,I5,I6,I7,A1,I8,I9,I10,I11,I12,I13)
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function receive an Index, which show the chosen matrices, and the  
%q-th image being processed.                                        
%This function then produce prints of the chosen matrices      
%PrintIndex:    The index of chosen matrices (m x 1)                      
%q:             The q-th image being processed            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
Index = find(PrintIndex>0);
Cond = isempty(Index);
 
if Cond == 0
    for i = 1:size(Index,1)
        ImageChosen = Index(i,1);
        if ImageChosen == 1
            imwrite(I2,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 2
            imwrite(I3,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 3
            imwrite(I4,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 4
            imwrite(I5,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 5
            imwrite(I6,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 6
            imwrite(I7,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 7
            imwrite(A1,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 8
            imwrite(I8,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 9
            imwrite(I9,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 10
            imwrite(I10,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 11
            imwrite(I11,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 12
            imwrite(I12,PrintNameList(q,i).name,'tif');
        elseif ImageChosen == 13
            imwrite(I13,PrintNameList(q,i).name,'tif');
        end
    end
    PrintList = size(Index,1);
else
    PrintList = 0;
end









MATLAB code for sub-function GeneratingPrintName.m
function [PrintNameList] = GeneratingPrintName(PrintIndex,s)
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function receive an Index, which show the chosen matrices, and the  
%number of images being processed.                                        
%This function then produce the list of names of the chosen matrices      
%PrintIndex:    The index of chosen matrices (m x 1)                      
%s:             The number of images being processed (1 x 1)              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
Index = find(PrintIndex>0);
Cond = isempty(Index);
 
if Cond == 0
    for i = 1:size(Index,1)
        ImageChosen = Index(i,1);
        if ImageChosen == 1
            PName = 'I2';
        elseif ImageChosen == 2
            PName = 'I3';
        elseif ImageChosen == 3
            PName = 'I4';
        elseif ImageChosen == 4
            PName = 'I5';
        elseif ImageChosen == 5
            PName = 'I6';
        elseif ImageChosen == 6
            PName = 'I7';
        elseif ImageChosen == 7
            PName = 'A1';
        elseif ImageChosen == 8
            PName = 'I8';
        elseif ImageChosen == 9
            PName = 'I9';
        elseif ImageChosen == 10
            PName = 'I10';
        elseif ImageChosen == 11
            PName = 'I11';
        elseif ImageChosen == 12
            PName = 'I12';
        elseif ImageChosen == 13
            PName = 'I13';
        end
        for j = 1:s
            PrintName = sprintf('%s-%03d.tif',PName,j);
            PrintNameList(j,i).name = PrintName;
        end
    end
else
    PrintNameList = 'NO PRINT CHOSEN';
end

