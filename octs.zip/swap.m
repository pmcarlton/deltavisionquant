  function [a, b] = swap (b, a) 
    endfunction 
